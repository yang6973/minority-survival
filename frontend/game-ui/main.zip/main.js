import {
  restartGameSession,
  prepareNextRound,
  submitPlayerChoice,
  useSharedRevive,

} from "../../game-engine/session-engine/gameSessionEngine.js";

import {
  buildRoundNarrative,
  buildResultNarrative,
} from "../../game-engine/narrative-engine/roundNarrativeEngine.js";

import {
  updateBestStreak,
} from "../../game-engine/retention-engine/recordEngine.js";

import {
  calculateSenseScore,
  buildSenseGrade,
  buildSenseTitle,
} from "../../game-engine/score-engine/senseScoreEngine.js";

import {
  buildLiveCrowdData,
} from "../../game-engine/live-engine/liveCrowdEngine.js";

let isProcessing = false;
let showRoundIntro = true;
let session = restartGameSession();

const DEV_MODE = false;
const app = document.getElementById("app");

function render() {
  if (!session || !session.currentRound) {
    app.innerHTML = `
      <main class="screen intro-home">
        <section class="home-card">
          <p class="intro-copy">
            남 눈치,<br />
            숨 쉬듯 보는 한국인들
          </p>

          <h1 class="game-title">
            눈치챙겨
          </h1>

          <p class="intro-sub">
            오늘은 또<br />
            어디서 눈치 보게 될까요?
          </p>

          <div class="tag-line">
            눈치 없는 사람이 이기는 게임
          </div>

          <div class="rule-mini">
            사람 많은 답 선택 = 탈락
          </div>

          <button id="startBtn">
            시작하기
          </button>
        </section>
      </main>
    `;

    document.getElementById("startBtn").onclick = startGame;
    return;
  }

  const round = session.currentRound;

  if (round.status === "WAITING_FOR_PLAYER") {
    if (showRoundIntro) {
      renderRoundIntro(round);

      setTimeout(() => {
        showRoundIntro = false;
        render();
      }, 900);

      return;
    }

    renderRound(round);
    return;
  }

  renderResult(round);
}

function renderRoundIntro(round) {
  const titleMap = {
    AVOID_AI_PREDICTION: "눈치 생존",
    TARGET_ZONE: "애매존 생존",
    REVERSE_TRAP: "반대 몰림 주의",
    BIAS_COLLAPSE: "쏠림 주의",
    MINORITY_SURVIVES: "소수 생존",
  };

  app.innerHTML = `
    <main class="screen intro-screen">
      <section class="intro-card">
        <p>ROUND ${round.roundNumber}</p>
        <h1>${titleMap[round.roundType] ?? "눈치 생존"}</h1>
        <span>이번 판, 사람들이 어디로 몰릴까요?</span>
      </section>
    </main>
  `;
}

function renderRound(round) {
  const narrative = buildRoundNarrative({
    roundType: round.roundType,
    question: round.question,
    prediction: round.prediction,
  });

  const liveCrowd = buildLiveCrowdData(round.prediction);

  app.innerHTML = `
    <main class="screen">
      <section class="top-bar">
        <div>ROUND ${round.roundNumber}</div>
        <div>STREAK ${session.survivalStreak}</div>
      </section>

      <section class="rule-card new-rule-card">
        <div class="rule-top">
          <span class="rule-spark">✦</span>

          <p class="rule-main-copy">
            눈치 없는 자가 살아남는 세상
          </p>
        </div>

        <h2 class="rule-main-title">
          ${narrative.ruleTitle}
        </h2>

        <div class="rule-box danger">
          <span class="rule-icon">✕</span>

          <span>
            많이 선택된 쪽은 탈락합니다.
          </span>
        </div>

        <div class="rule-box safe">
          <span class="rule-icon">✓</span>

          <span>
            적게 선택된 쪽만 살아남아요.
          </span>
        </div>
      </section>

      <section class="signal-card">
        <p class="eyebrow">QUESTION</p>
        <h1>${round.question.text}</h1>
      </section>

      <section class="live-crowd-card">
        <div class="live-row">
          <span>현재 참가자</span>
          <strong>${liveCrowd.participantCount.toLocaleString()}명</strong>
        </div>

        <div class="live-row trend">
          <span>실시간 분위기</span>
          <strong>${liveCrowd.trendMessage}</strong>
        </div>
      </section>

      <section class="ai-warning">
        <div class="boksil-row">
          <div class="boksil-orb">
            <span></span>
            <span></span>
          </div>

          <p>${narrative.preChoiceMessage}</p>
        </div>

        <span>${narrative.pressureMessage}</span>
      </section>

      <section class="choice-grid">
        <button class="choice-btn" data-choice="A">
          ${round.question.optionA}
        </button>

        <button class="choice-btn" data-choice="B">
          ${round.question.optionB}
        </button>
      </section>

      <p class="hint">
        정답은 없습니다. 사람들이 어디로 몰릴지 피하세요.
      </p>
    </main>
  `;

  document.querySelectorAll(".choice-btn").forEach((btn) => {
    btn.onclick = async () => {
      if (isProcessing) {
        return;
      }

      isProcessing = true;

      const choice = btn.dataset.choice;

      renderProcessingScreen(choice);

      await wait(1000);

      renderRevealLoading();

      await wait(1800);

      session = submitPlayerChoice(session, choice);

      isProcessing = false;

      render();
    };
  });
}

function renderResult(round) {
  const survived = round.survived;
  const resultNarrative = buildResultNarrative(round);

  const playerPercent =
    round.playerChoice === "A"
      ? round.prediction.predictedA
      : round.prediction.predictedB;

  const crowdLevel = getCrowdLevel(playerPercent, survived);
  const isNearMiss = !survived && playerPercent <= 55;

  const record = updateBestStreak(session.survivalStreak);

  const senseScore = calculateSenseScore(round);
  const senseGrade = buildSenseGrade(senseScore);
  const senseTitle = buildSenseTitle(senseScore);

  const canUseShareRevive =
    !survived &&
    session.survivalStreak >= 3 &&
    !session.sharedReviveUsed;

  app.innerHTML = `
    <main class="screen result ${survived ? "survived" : "eliminated"}">
      <section class="result-card">
        <p class="eyebrow">
          ${survived ? "SURVIVED" : "OUT"}
        </p>

        <h1>
          ${survived ? "살았어요" : "탈락했어요"}
        </h1>

        <div class="crowd-result">
          <div class="crowd-row">
            <span>A ${round.question.optionA}</span>
            <strong id="percentA">0%</strong>
          </div>

          <div class="bar">
            <div
              class="bar-fill"
              style="width: ${round.prediction.predictedA}%"
            ></div>
          </div>

          <div class="crowd-row">
            <span>B ${round.question.optionB}</span>
            <strong id="percentB">0%</strong>
          </div>

          <div class="bar">
            <div
              class="bar-fill"
              style="width: ${round.prediction.predictedB}%"
            ></div>
          </div>
        </div>

      <div class="result-stats-grid">

        <div class="my-choice-card">
          <p>내 선택</p>

          <strong>
            ${round.playerChoice === "A"
              ? round.question.optionA
              : round.question.optionB}
          </strong>

          <span>
            <b id="playerPercent">0%</b>가 같은 선택을 했어요
          </span>
        </div>

        <div class="sense-score-card">
          <p>눈치력</p>

          <strong>${senseScore}</strong>

          <span class="sense-title">
            ${senseTitle}
          </span>

          <small>
            ${senseGrade}
          </small>
        </div>

      </div>
      
        <p class="result-message">
          ${resultNarrative}
        </p>

        ${
          DEV_MODE
            ? `
              <div class="debug-rule-card">
                <p>DEV CHECK</p>
                <span>ROUND TYPE: ${round.roundType}</span>
                <span>MY PERCENT: ${playerPercent}%</span>
                <span>RESULT: ${survived ? "SURVIVED" : "OUT"}</span>
              </div>
            `
            : ""
        }

        <p class="near-message ${isNearMiss ? "near-hit" : ""}">
          ${crowdLevel}
        </p>

        <div class="record-card">
          <div>
            <span>현재 기록</span>
            <strong>${session.survivalStreak}R</strong>
          </div>

          <div>
            <span>최고 기록</span>
            <strong>${record.bestStreak}R</strong>
          </div>
        </div>

        ${
          record.isNewRecord
            ? `<p class="new-record">🔥 최고 기록 갱신!</p>`
            : ""
        }

        ${
          canUseShareRevive
            ? `
              <div class="share-revive-notice">
                <strong>복실이가 마지막 기회를 봐뒀어요</strong>
                <span>공유가 완료되면 이번 기록을 이어갈 수 있어요.</span>
              </div>
            `
            : ""
        }

        <div class="result-actions">
          ${
            canUseShareRevive
              ? `
                <button id="shareReviveBtn" class="secondary-btn share-revive-btn">
                  공유하고 한 번 더 살아보기
                </button>
              `
              : ""
          }

          <button id="nextBtn">
            ${survived ? "다음 라운드 가기" : "처음부터 다시"}
          </button>
        </div>
      </section>
    </main>
  `;

  requestAnimationFrame(() => {
    animatePercentage(
      document.getElementById("percentA"),
      round.prediction.predictedA
    );

    animatePercentage(
      document.getElementById("percentB"),
      round.prediction.predictedB
    );

    animatePercentage(
      document.getElementById("playerPercent"),
      playerPercent
    );
  });

  const shareReviveBtn =
    document.getElementById("shareReviveBtn");

  if (shareReviveBtn) {
    shareReviveBtn.onclick = async () => {
      const shared = await tryShareResult();

      if (!shared) {
        renderShareFailedCard();
        return;
      }

      renderSharedReviveCard();
    };
  }

  document.getElementById("nextBtn").onclick = () => {
    if (survived) {
      session = prepareNextRound(session);
      showRoundIntro = true;
    } else {
      session = restartGameSession();
      showRoundIntro = true;
    }

    render();
  };
}

function getCrowdLevel(playerPercent, survived) {
  if (survived) {
    if (playerPercent >= 45) {
      return "진짜 아슬아슬했어요. 거의 같이 몰릴 뻔했어요.";
    }

    if (playerPercent >= 38) {
      return "적당히 잘 피했어요.";
    }

    return "깔끔하게 몰림을 피했어요.";
  }

  if (playerPercent <= 55) {
    return "거의 생존할 뻔...\n진짜 한 끗 차이였어~!";
  }

  if (playerPercent <= 65) {
    return "생각보다 사람들이 많이 같은 선택을 했어요.";
  }

  return "너무 많이 몰렸어요. 다들 비슷하게 생각했어요.";
}

function startGame() {
  session = restartGameSession();
  showRoundIntro = true;
  render();
}

function renderProcessingScreen(choice) {
  app.innerHTML = `
    <main class="screen thinking-screen">
      <section class="thinking-card">
        <p class="thinking-label">
          선택 완료
        </p>

        <h1>
          ${choice === "A" ? "A 선택" : "B 선택"}
        </h1>

        <div class="thinking-dots">
          <span></span>
          <span></span>
          <span></span>
        </div>

        <p class="thinking-message">
          참가자 반응 분석 중...
        </p>
      </section>
    </main>
  `;
}

function renderRevealLoading() {
  app.innerHTML = `
    <main class="screen thinking-screen">
      <section class="thinking-card reveal-card">
        <p class="thinking-label">
          실시간 집계 중
        </p>

        <h1>
          어디로 몰렸을까?
        </h1>

        <div class="crowd-flow">
          <div class="runner r1"></div>
          <div class="runner r2"></div>
          <div class="runner r3"></div>
          <div class="runner r4"></div>
          <div class="runner r5"></div>
        </div>

        <p class="thinking-message">
          참가자 선택 비율 계산 중...
        </p>
      </section>
    </main>
  `;
}

function renderSharedReviveCard() {
  app.innerHTML = `
    <main class="screen thinking-screen">
      <section class="thinking-card revive-card">
        <p class="thinking-label">
          LAST CHANCE
        </p>

        <div class="boksil-orb revive-orb">
          <span></span>
          <span></span>
        </div>

        <h1>
          마지막 기회 획득
        </h1>

        <p class="thinking-message">
          복실이가 다시 들여보내줬어요.<br />
          이번엔 사람들 몰림을 더 잘 피해야 해요.
        </p>

        <button id="confirmReviveBtn">
          다시 살아남기
        </button>
      </section>
    </main>
  `;

  document.getElementById("confirmReviveBtn").onclick = () => {
    session = useSharedRevive(session);
    showRoundIntro = true;
    render();
  };
}

function renderShareFailedCard() {
  app.innerHTML = `
    <main class="screen thinking-screen">
      <section class="thinking-card revive-card">
        <p class="thinking-label">
          SHARE CANCELED
        </p>

        <h1>
          공유가 취소됐어요
        </h1>

        <p class="thinking-message">
          공유가 완료되면 마지막 기회를 받을 수 있어요.
        </p>

        <button id="backToResultBtn">
          결과로 돌아가기
        </button>
      </section>
    </main>
  `;

  document.getElementById("backToResultBtn").onclick = () => {
    render();
  };
}

function buildShareText() {
  const messages = [
    `나는 눈치챙겨에서 ${session.survivalStreak}R까지 생존했어.\n복실이도 못 읽은 선택이었다 👀`,
    `눈치챙겨 ${session.survivalStreak}R 생존.\n사람들 어디 몰릴지 맞히는 거 은근 어렵다.`,
    `나 방금 ${session.survivalStreak}R까지 감.\n너도 사람들 몰리는 쪽 피할 수 있나 해봐.`,
    `복실이 예측 피해서 ${session.survivalStreak}R 생존.\n이거 생각보다 눈치 싸움임.`,
    `눈치력 테스트 완료.\n나는 ${session.survivalStreak}R까지 살아남았다.`,
  ];

  return messages[
    Math.floor(Math.random() * messages.length)
  ];
}

async function tryShareResult() {
  const shareText = buildShareText();
  const shareUrl = window.location.href;

  try {
    if (navigator.share) {
      await navigator.share({
        title: "눈치챙겨",
        text: shareText,
        url: shareUrl,
      });

      return true;
    }

    await navigator.clipboard.writeText(
      `${shareText}\n${shareUrl}`
    );

    return true;
  } catch (error) {
    return false;
  }
}

function wait(ms) {
  return new Promise((resolve) => {
    setTimeout(resolve, ms);
  });
}

function animatePercentage(element, target) {
  if (!element) {
    return;
  }

  let current = 0;

  const duration = 700;
  const stepTime = 16;
  const increment = target / (duration / stepTime);

  const timer = setInterval(() => {
    current += increment;

    if (current >= target) {
      current = target;
      clearInterval(timer);
    }

    element.textContent = `${Math.round(current)}%`;
  }, stepTime);
}

render();